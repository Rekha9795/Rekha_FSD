package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CategoryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int categoryId;
	private String categoryNmae;
	private String briefDetails;
	public CategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryNmae() {
		return categoryNmae;
	}
	public void setCategoryNmae(String categoryNmae) {
		this.categoryNmae = categoryNmae;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public CategoryEntity(int categoryId, String categoryNmae, String briefDetails) {
		super();
		this.categoryId = categoryId;
		this.categoryNmae = categoryNmae;
		this.briefDetails = briefDetails;
	}
	
	
	
	

}
