package com.cts.entity;

import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	private int userId;
	
	private String transactionType;
	private Date dateTime;
	private String tranRemarks;
	
	public TransactionEntity() {
		
	}
	public int getTranId() {
		return transactionId;
	}
	public void setTranId(int tranId) {
		this.transactionId = tranId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTranRemarks() {
		return tranRemarks;
	}
	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}
	public TransactionEntity(int tranId, int userId, int sellerId, String transactionType, String tranRemarks) {
		super();
		this.transactionId = tranId;
		this.userId = userId;
		
		this.transactionType = transactionType;
		this.tranRemarks = tranRemarks;
	}
	@Override
	public String toString() {
		return "TransactionEntity [tranId=" + transactionId + ", userId=" + userId + ",  transactionType=" + transactionType + ", tranRemarks=" + tranRemarks + "]";
	}


}
