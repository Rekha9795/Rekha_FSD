import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl='http://localhost:8389/MatchItems'
 
  constructor(private http: HttpClient) { }

  searchitems(itemName:String) :Observable<any>  {
    console.log(itemName);
    return this.http.get(`${this.baseUrl}/${itemName}`);
  }
}
