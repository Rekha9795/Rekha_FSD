package com.egg.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.model.BuyerEntity;


@Service(value = "userService")
public class BuyerService implements IBuyerService, UserDetailsService {
	
	@Autowired
	private BuyerDao bdao;
	
	
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerEntity user = bdao.findByuserName(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}


	
	@Override
	public List<BuyerEntity> getAllBuyers() {
		return bdao.findAll();
	}

    
	@Override
	public BuyerEntity add(BuyerEntity buyer) {
    buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
	return bdao.save(buyer);
	}

	@Override
	public BuyerEntity findOne(String username) {
		return bdao.findByuserName(username);
		
	}

	@Override
	public BuyerEntity findById(int id) {
		
		Optional<BuyerEntity> optionalUser =bdao.findById(id); 
		return optionalUser.isPresent() ? optionalUser.get() : null;
	}

	
	
	

}
