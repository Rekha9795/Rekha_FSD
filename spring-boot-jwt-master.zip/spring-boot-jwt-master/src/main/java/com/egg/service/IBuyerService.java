package com.egg.service;

import java.util.List;


import com.egg.model.BuyerEntity;



public interface IBuyerService {

	List<BuyerEntity> getAllBuyers();
	BuyerEntity add(BuyerEntity buyer);
	 BuyerEntity findOne(String username);
	BuyerEntity findById(int id);
	
	

}
