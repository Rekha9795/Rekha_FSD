package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cts.dao.ItemsDao;
import com.cts.dao.SellerDao;
import com.cts.sellerEntity.ItemsEntity;
import com.cts.sellerEntity.SellerEntity;

@Service
public class ItemsService implements IItemsService {
	@Autowired
	private SellerDao sdao;
	
	
	@Autowired
	private ItemsDao itemdao;

	@Override
	public String addItem(int sid, ItemsEntity items) {
		SellerEntity sr=sdao.getOne(sid);
		items.setSellerEntity(sr);
		System.out.println(items);
		itemdao.save(items);
		return "Return Seller item";
	}

	@Override
	public List<ItemsEntity> getAllItems() {
		return itemdao.findAll();
	}

	@Override
	public void deleteBySid(Integer sid, Integer itemid) {
		itemdao.deleteBySid(sid,itemid);
	}

	@Override
	public List<ItemsEntity> viweItem(Integer sellerId) {
		
		return itemdao.viweItem(sellerId);
	}

	@Override
	public String updateItem(ItemsEntity itemsId, Integer sellerId, Integer iId) {
		ItemsEntity update=itemdao.getbyid(sellerId,iId);
		System.out.println(itemsId);
		float cost=itemsId.getPrice();
		int stockNumber=itemsId.getStockNumber();
		update.setPrice(cost);
		update.setStockNumber(stockNumber);
		System.out.println(update);
		itemdao.save(update);
	return "updated";
		
	}

	@Override
	public List<ItemsEntity> getMatchItem(String iName) {
		
		
		return itemdao.findMatchItem(iName) ;
	}


     
	

	
	
	
	
	


	
	

}
