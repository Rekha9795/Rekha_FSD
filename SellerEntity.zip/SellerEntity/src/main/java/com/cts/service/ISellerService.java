package com.cts.service;

import java.util.List;

import com.cts.sellerEntity.SellerEntity;

public interface ISellerService {

	List<SellerEntity> gatAllSellers();

	SellerEntity add(SellerEntity seller);
	
	

}
