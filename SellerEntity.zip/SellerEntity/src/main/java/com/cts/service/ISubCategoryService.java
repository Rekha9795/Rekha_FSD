package com.cts.service;

import java.util.List;

import com.cts.controller.SubCategoryController;
import com.cts.sellerEntity.SubCategoryEntity;

public interface ISubCategoryService {

	List<SubCategoryEntity> getAllSubCat();
	

}
