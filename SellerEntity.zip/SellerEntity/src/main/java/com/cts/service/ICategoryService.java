package com.cts.service;

import java.util.List;

import com.cts.sellerEntity.CategoryEntity;
import com.cts.sellerEntity.SellerEntity;

public interface ICategoryService {

	List<CategoryEntity> getAllCat();
	

	
	

}
