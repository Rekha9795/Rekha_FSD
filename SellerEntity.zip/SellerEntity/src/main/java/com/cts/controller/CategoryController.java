package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.sellerEntity.CategoryEntity;
import com.cts.sellerEntity.SellerEntity;
import com.cts.service.ICategoryService;

@RestController
public class CategoryController {
	@Autowired
	private ICategoryService icser;
	
	@GetMapping("/getAll")
	public List<CategoryEntity> getAll(){
	return icser.getAllCat();
}

}
