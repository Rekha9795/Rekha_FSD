package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.sellerEntity.ItemsEntity;
import com.cts.sellerEntity.SellerEntity;
import com.cts.sellerEntity.SubCategoryEntity;
import com.cts.service.ISubCategoryService;

@RestController
public class SubCategoryController {
	@Autowired
	private ISubCategoryService icatser;
	
	@GetMapping("/getAllItems1")
	public List<SubCategoryEntity> getAll(){
    return icatser.getAllSubCat();
	}
	

}
