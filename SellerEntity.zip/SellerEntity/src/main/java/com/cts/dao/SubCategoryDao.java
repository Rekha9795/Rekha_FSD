package com.cts.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.sellerEntity.SubCategoryEntity;

public interface SubCategoryDao extends JpaRepository<SubCategoryEntity, Integer>{

}
