package com.cts.sellerEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SellerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sellerId;
	private String sellername;
	private String password;
	private String companyname;
	@Column(name="gstin")
	private long GSTIN;
	private String briefAboutCompany;
	private String postal_address;
	private String website;
	private String emailid;
	private long contactNumber;
	
	public SellerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellername() {
		return sellername;
	}

	public void setSellername(String sellername) {
		this.sellername = sellername;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}



	public long getGSTIN() {
		return GSTIN;
	}

	public void setGSTIN(long gSTIN) {
		GSTIN = gSTIN;
	}

	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}

	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}

	public String getPostal_address() {
		return postal_address;
	}

	public void setPostal_address(String postal_address) {
		this.postal_address = postal_address;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	
	

	public SellerEntity(int sellerId, String sellername, String password, String companyname, long gSTIN,
			String briefAboutCompany, String postal_address, String website, String emailid, long contactNumber) {
		super();
		this.sellerId = sellerId;
		this.sellername = sellername;
		this.password = password;
		this.companyname = companyname;
		GSTIN = gSTIN;
		this.briefAboutCompany = briefAboutCompany;
		this.postal_address = postal_address;
		this.website = website;
		this.emailid = emailid;
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "SellerEntity [sellerId=" + sellerId + ", sellername=" + sellername + ", password=" + password
				+ ", companyname=" + companyname + ", GSTIN=" + GSTIN + ", briefAboutCompany=" + briefAboutCompany
				+ ", postal_address=" + postal_address + ", website=" + website + ", emailid=" + emailid
				+ ", contactNumber=" + contactNumber + "]";
	}

	

	
	
	
	
	
	
}

