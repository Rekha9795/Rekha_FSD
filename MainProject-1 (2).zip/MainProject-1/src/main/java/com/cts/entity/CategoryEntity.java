package com.cts.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CategoryEntity {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int categoryId;
	@OneToMany(cascade = CascadeType.ALL,   mappedBy="catog")
	private List<SubCategoryEntity> subcat;
	
	private String categoryNmae;
	private String briefDetails;
	
	
	public CategoryEntity() {
		
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryNmae() {
		return categoryNmae;
	}
	public void setCategoryNmae(String categoryNmae) {
		this.categoryNmae = categoryNmae;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public CategoryEntity(int categoryId, String categoryNmae, String briefDetails) {
		super();
		this.categoryId = categoryId;
		this.categoryNmae = categoryNmae;
		this.briefDetails = briefDetails;
	}
	@Override
	public String toString() {
		return "CategoryEntity [categoryId=" + categoryId + ", categoryNmae=" + categoryNmae + ", briefDetails="
				+ briefDetails + "]";
	}
	
	
}
