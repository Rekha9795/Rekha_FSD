package com.cts.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.BuyerDao;
import com.cts.entity.BuyerEntity;
//import com.cts.entity.ItemsEntity;
@Service
public class BuyerService {
	
@Autowired
public BuyerDao buyerdao;

	public List<BuyerEntity> getItems()
	{
		
		return  buyerdao.findAll();
	}

	


}
