package com.cts;

public class ArrayRev {
	public static void main(String args[]) {
	 int arr[]= {10,20,30,40,50};
		int temp;
		int k=arr.length-1;
		int j=arr.length;
		
		  //for(int i=0;i<arr.length;i++) { 
			 // System.out.println(arr[i]);
			 // }
		 for(int i=0;i<j/2;i++) 
		 {
			 temp=arr[i];
			arr[i]=arr[k];
			arr[k]=temp;
			k--;
			
			
		 }
		 for(int i=0;i<j;i++) {
			 System.out.println(arr[i]);
		 }
			
		 
	}
	
	
}
