package com.cts.exception;

public class ArithmaticException1 {
	static void avg() throws ArithmeticException {
		System.out.println("Inside the avg function");
		throw new ArithmeticException();
	}

	public static void main(String[] args) {
	try {
		avg();
		// TODO Auto-generated method stub
	}
finally {
	System.out.println("caught");
}
	}


}
