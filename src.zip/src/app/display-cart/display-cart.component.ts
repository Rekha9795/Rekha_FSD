import { Component, OnInit } from '@angular/core';
import { ShoppingCartEntity } from '../ShoppingCartEntity';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {
displaycart: ShoppingCartEntity[];
  constructor(private discart:BuyerServiceService) { }

  ngOnInit(): void {
this.discart.displayCartItems()
.subscribe(displaycart=> this.displaycart= displaycart);
console.log(this.displaycart);

  }

}
