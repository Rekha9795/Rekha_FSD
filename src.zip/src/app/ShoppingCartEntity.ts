export class ShoppingCartEntity{
    itemId: number
    quantity: number
    price: number
 
  
}