import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCartEntity } from './ShoppingCartEntity';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
  


  constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8339/addToCart/BuyerId";
  addToCart(cart: ShoppingCartEntity ) :Observable<any>{
    return this.http.post(`${this.baseUrl1}/3`,cart);
  }

  
private baseUrl="http://localhost:8389/MatchItems";

getItemByName(itemName: String) :Observable<any> {
  return this.http.get(`${this.baseUrl}/${itemName}`);
}


 private baseUrl2="http://localhost:8339/getAll/CartItem"; 
displayCartItems() :Observable<any> {
 return this.http.get(`${this.baseUrl2}`);
}
  
  
  
  
}
