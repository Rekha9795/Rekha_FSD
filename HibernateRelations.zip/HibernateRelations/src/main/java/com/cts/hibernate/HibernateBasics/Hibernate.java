package com.cts.hibernate.HibernateBasics;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Cart;
import com.cts.hibernate.model.CartItem;

public class Hibernate {
	public static void main(String args[]) {
		Configuration configuration=new Configuration().configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		
		CartItem ct=new CartItem();
		ct.setCartItemId(1);
		ct.setQuantity(4);
		
		Cart c=new Cart();
		c.setCartId(2);
		c.setDescription("first!!");
		c.setCt(ct);
		
		session.beginTransaction();
		session.save(ct);
		session.save(c);
		session.getTransaction().commit();
		session.close();
		
	}

}
