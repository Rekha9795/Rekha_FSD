package com.cts.hibernate.model;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.mapping.List;


@Entity
public class CartItem  {
	@Id
	@GeneratedValue
	private int cartItemId;
	private int quantity;
	
	//@ManyToOne
	
	//private Cart c;
	//public Cart getC() {
		//return c;
	//}

	public void setC(Cart c) {
		this.c = c;
	}

	public CartItem() {
		
	}
	
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	

	
	
	

}
