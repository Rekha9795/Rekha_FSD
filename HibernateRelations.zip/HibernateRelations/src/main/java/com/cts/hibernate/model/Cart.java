package com.cts.hibernate.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Cart implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartId;
	private String description;
	
	
	  @OneToOne
	 private CartItem ct;
	  
	  public CartItem getCt() {
	   return ct; 
	   }
	    public void setCt(CartItem ct) {
	  this.ct = ct; 
	  }
	 
	
	
	public Cart() {
		
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Cart(int cartId, String description) {
		super();
		this.cartId = cartId;
		this.description = description;
	}
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", description=" + description + "]";
	}
	

}
