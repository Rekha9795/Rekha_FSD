package com.cts.entity.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.BuyerEntity;
import com.cts.entity.PurchaseHistoryEntity;
import com.cts.entity.ShoppingCartEntity;
import com.cts.entity.TransactionEntity;
import com.cts.entity.dao.BuyerDao;
import com.cts.entity.dao.CartDao;
import com.cts.entity.dao.PurchaseDao;
import com.cts.entity.dao.TransactionDao;
@Service
public class CartService implements IcartService {
	@Autowired
	private BuyerDao bdao;
	
	@Autowired
	private CartDao cdao;
	
	@Autowired
	private TransactionDao tdao;
	
	@Autowired
	private PurchaseDao pdao;
	
	//@Autowired
	//private ItemsDao idao;
	
	@Override
	public String addCart(int bid, ShoppingCartEntity cItem) {
		BuyerEntity br=bdao.getOne(bid);
		cItem.setBuyer(br);  
		System.out.println(cItem);
		 cdao.save(cItem);
		 return "Return buyer";
	}

	
	
	
	
	@Override
public List<ShoppingCartEntity> getAllCart() {
		
		return cdao.findAll();
	}
	
	
	@Override
	public Optional<ShoppingCartEntity> getPersonById(int id) {
		
		return cdao.findById(id);
	}
	
	
	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCartEntity> buyer = cdao.findById(bId);
		
		if(buyer.isPresent()) {
			cdao.deleteById(bId);
		}
		
	}

	
	
	@Override
	public void deleteAllCart() {
		cdao.deleteAll();
		
	}


	@Override
	public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String updateCart(int cid, ShoppingCartEntity scart1) 
	{
		
		ShoppingCartEntity update=cdao.getOne(cid);
		
		int quantity=scart1.getQuantity();
		update.setQuantity(quantity);
		System.out.println(update);
		cdao.save(update);
		return "\"Cart item updated\"";
	}





	@Override
	public String checkOut(TransactionEntity transac, int buyerid) {
		BuyerEntity buyer=bdao.getOne(buyerid);
		System.out.println(buyer);
		transac.setUser(buyer);
		System.out.println(transac);
		tdao.save(transac);	
		List<ShoppingCartEntity> shcart1=cdao.byid(buyerid);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistoryEntity phistory=new PurchaseHistoryEntity();
			ShoppingCartEntity shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			
			phistory.setNumberOfItems(size);
			phistory.setUser(buyer);
			System.out.println(phistory);
			//System.out.println(shcartitems);
      		cdao.deleteById(shcartitems.getCartId());
			pdao.save(phistory);
			
			
		}
		return "Transaction complited succeccfully";
	}

	

	
	

	
	
	

}
