package com.cts.entity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.BuyerEntity;
import com.cts.entity.ShoppingCartEntity;
import com.cts.entity.dao.BuyerDao;
@Service
public class BuyerService implements IBuyerService {
	
	@Autowired
	private BuyerDao bdao;

	
	@Override
	public List<BuyerEntity> getAllBuyers() {
		return bdao.findAll();
	}

    
	@Override
	public BuyerEntity add(BuyerEntity buyer) {
	return bdao.save(buyer);
	}
	
	

}
