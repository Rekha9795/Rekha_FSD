package com.cts.entity.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.TransactionEntity;

public interface TransactionDao extends JpaRepository<TransactionEntity, Integer> {

}
