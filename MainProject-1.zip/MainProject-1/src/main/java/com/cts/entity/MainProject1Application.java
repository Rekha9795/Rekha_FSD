package com.cts.entity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages ="com.cts.entity")
public class MainProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(MainProject1Application.class, args);
	}

}
