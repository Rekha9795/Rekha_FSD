package com.cts.entity.dao;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.entity.ShoppingCartEntity;
@Repository
public interface CartDao extends JpaRepository<ShoppingCartEntity, Integer> {

	
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM shopping_cart_entity WHERE shopping_cart_entity.buyer_id = :buid",nativeQuery = true)
	public List<ShoppingCartEntity> byid(@Param("buid") int buyerid);

	

	
	

	


	
}
