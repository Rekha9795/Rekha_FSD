package com.cts.entity.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.entity.ItemsEntity;

@Repository
public interface ItemsDao extends JpaRepository<ItemsEntity, Integer>{

}
