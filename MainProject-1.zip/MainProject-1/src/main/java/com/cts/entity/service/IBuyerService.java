package com.cts.entity.service;

import java.util.List;

import com.cts.entity.BuyerEntity;
import com.cts.entity.ShoppingCartEntity;

public interface IBuyerService {

	List<BuyerEntity> getAllBuyers();
	BuyerEntity add(BuyerEntity buyer);

	
	

}
