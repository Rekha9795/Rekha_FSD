package com.cts.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class ItemsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	private float price;
	private String itemName;
	private int stockNumber;
	private String description;
	private String remarks;
	
	
	
	
	


	public ItemsEntity() {
		
	}
	
	
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public ItemsEntity(int itemId, float price, String itemName, int stockNumber, String description, String remarks) {
		super();
		this.itemId = itemId;
		this.price = price;
		this.itemName = itemName;
		this.stockNumber = stockNumber;
		this.description = description;
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "ItemsEntity [itemId=" + itemId + ", price=" + price + ", itemName=" + itemName + ", stockNumber="
				+ stockNumber + ", description=" + description + ", remarks=" + remarks + "]";
	}
	
	
	
	

}
