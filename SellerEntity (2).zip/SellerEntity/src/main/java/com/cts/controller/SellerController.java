package com.cts.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cts.sellerEntity.SellerEntity;
import com.cts.service.ISellerService;

@RestController
public class SellerController {
	
	@Autowired
	public ISellerService iser;
	
	
	@GetMapping("/getAllSellers")
	public List<SellerEntity> getAll(){
	return iser.gatAllSellers();
}
	
	@RequestMapping(value="/addSellers", method= RequestMethod.POST, produces="application/json")
	
		public SellerEntity addBuyer(@RequestBody SellerEntity seller) {
			
			return iser.add(seller);
		}
		
		
	}
	

