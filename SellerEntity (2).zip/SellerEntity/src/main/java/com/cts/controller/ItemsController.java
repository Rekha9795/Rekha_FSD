package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.sellerEntity.ItemsEntity;
import com.cts.service.IItemsService;

@RestController
public class ItemsController {
	@Autowired
	private IItemsService iitemser;
	
	//adding items using sellerId:
	@PostMapping("/add/BySellid/{sid}")
	public String addItem(@PathVariable("sid")int sid, @RequestBody ItemsEntity items) {
		return iitemser.addItem(sid,items);
	}
	//getting all Items. It includes both Seller and Items details:
	@GetMapping("/getAllItems")
	public List<ItemsEntity> getAll(){
    return iitemser.getAllItems();
	}
	
	//delete an item using SellerId:
	@DeleteMapping("/deleteBySid/{sid}/{itemId}")
	public void deleteBySid(@PathVariable("sid") Integer sid, @PathVariable("itemId") Integer itemId) {
	 iitemser.deleteBySid(sid,itemId);	

	}
	
//selecting Items using sellerId:
	@GetMapping("/getAllItems/{sid}")
	public List<ItemsEntity> viewItems(@PathVariable("sid") Integer sellerId){
	return 	iitemser.viweItem(sellerId);
	}

	
	//Updating the item using SellerId, at the same time it includes  ItemId also:
	/*@PostMapping("/updatebySid/{sid}/{iId}")
	public String updateItem(@PathVariable("sid") Integer sellerId,@PathVariable("iId") Integer iId,@RequestBody ItemsEntity itemsId) {
		return iitemser.updateItem(sellerId,iId,itemsId);
		
	}*/
	
}
