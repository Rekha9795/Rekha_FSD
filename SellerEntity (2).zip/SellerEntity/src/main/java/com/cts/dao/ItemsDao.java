package com.cts.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.sellerEntity.ItemsEntity;
import com.cts.sellerEntity.SellerEntity;

@Repository
public interface ItemsDao extends JpaRepository<ItemsEntity,Integer>{

	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM items_entity WHERE item_id = :itemid AND seller_entity_seller_id=:sid ",nativeQuery = true)
	void deleteBySid(@Param("sid") Integer sellerId , @Param("itemid") Integer itemId);

	@Query(value = "SELECT * FROM items_entity i WHERE i.seller_entity_seller_id=:sellerId ",nativeQuery = true)
	List<ItemsEntity> viweItem(@Param("sellerId") Integer sellerId);


	

	
	

	
	
	

	

}
