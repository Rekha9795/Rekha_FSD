import { Component } from '@angular/core';
import {User} from './user'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
 // template:`<p>i am here</p>`,
  styleUrls: ['./app.component.css']
})

export class AppComponent {
isValid = true;
count=0;
ids = [1,2,3,4];
title = 'app';

	users = [
      new User('Mahesh', 20,'rekhapulluru9795@.com'),
      new User('Krishna', 22,'tdtydfd@gmai.com'),
      new User('Narendra', 31,'vxwfigqdb@gmail.com')
    ];
     myfun(){
      this.count++;
      if(this.isValid){
        this.isValid=false;
      }
        else
        {
          this.isValid=true;
        }
       
      

    }
    
 }


