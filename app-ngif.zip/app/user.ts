export class User {
    public name:string;
    public age:number;
    public mail:string;

    constructor(name:string,age:number,mail:string){
        this.name=name;
        this.age=age;
        this.mail=mail;
    }
       

   
}