package com.cts.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class Product {
	
	private int prodId;
	@NotBlank(message="name cannot be empty")
	@Size(min=3,max=8,message="name should min 3 chars")
	private String prodName;
	@NotNull(message="quantity cannot be empty")
	private Integer quantity;
	
	private float price;//?

	public Product() {
		System.out.println("i am product constructor");
	}

	public Product(int prodId, String prodName, int quantity, float price) {
		this.prodId = prodId;
		this.prodName = prodName;
		this.quantity = quantity;
		this.price = price;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}

}
