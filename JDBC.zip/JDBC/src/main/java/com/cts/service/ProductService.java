package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.dao.ProductDao;
import com.cts.model.Product;
@Service
public class ProductService {
	
	@Autowired
	private ProductDao pDao;
	
	public int addProduct(Product product){
		
		return pDao.addProduct(product);
	}
	
}
