package com.cts.pms.dao;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.model.Product;

@Repository
public class ProductDao extends JdbcDaoSupport{

	//@Autowired//bytype
/*	private DataSource ds;
	private JdbcTemplate jdbc;
	
	@Autowired
	public void setDs(DataSource ds) {
		this.ds=ds;
		jdbc=new JdbcTemplate(this.ds);
	}
	
*/	
	public int addProduct(Product product){
		int storedStatus=getJdbcTemplate().update("INSERT INTO product values(?,?,?,?)",new Object[]{product.getProdId(),product.getProdName(),product.getQuantity(),product.getPrice()});
		System.out.println(storedStatus);
		return product.getProdId();
		
	}
	
}




