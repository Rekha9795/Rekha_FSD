package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ProdDao;
import com.cts.product.ProdModel;

@Service
public class ProdService {
	@Autowired
	private ProdDao productDao;
	public int addProdModel(ProdModel product){
			
			return productDao.addProduct(product);
		}


	public ProdModel getProductById(int productid) {
		{
			ProdModel product =  productDao.getProductById(productid);
			return product;
		}
		
	}
	public int updateProdModel(ProdModel product)
	{
		return productDao.updateProduct(product);
	}
	
	public int deleteProdModel(int productId)
	{
		return productDao.deleteProduct(productId);
	}

	

	}
		
	
	


