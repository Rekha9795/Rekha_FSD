package com.cts.dao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.cts.product.ProdModel;

@Repository
public class ProdDao extends JdbcDaoSupport {

	public int addProduct(ProdModel product) {
		
		int storedStatus=getJdbcTemplate().update("INSERT INTO product values(?,?,?,?)",new Object[]{product. getProductId(),product. getProductName(),product.getProductQuantity(),product.getProductPrice()});
		System.out.println(storedStatus);
		return product.getProductId();
	}

	public int updateProduct(ProdModel product) {
		int updateStatus=getJdbcTemplate().update("UPDATE product set product_name = ? , product_quantity = ? , product_description = ? where product_id = ?",new Object[]{product. getProductId(),product. getProductName(),product.getProductQuantity(),product.getProductPrice()});
	//	System.out.println(updateStatus);
		return updateStatus;
	}
public int deleteProduct(int productId) {
		
		int deletedStatus=getJdbcTemplate().update("DELETE from product WHERE product_id = ?",new Object[]{productId});
		System.out.println(deletedStatus);
		return deletedStatus;
	}
public ProdModel getProductById(int productId) {
	   ProdModel product = getJdbcTemplate().queryForObject("SELECT * FROM product WHERE product_id = ?",
			     new Object[] { productId }, new BeanPropertyRowMapper<ProdModel>(ProdModel.class));
	return product;
}


}


	


