package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.product.ProdModel;
import com.cts.service.ProdService;

public class Prodcontroller {
	@Autowired
	private ProdService productService;
	
	
	//displayProductById
	@RequestMapping(value = "/Product/{pid}", method = RequestMethod.GET)
	public ResponseEntity<ProdModel> getProductById(@PathVariable("pid") int productid) {
		
		ProdModel product = productService.getProductById(productid);
		if (product == null) {
			   return new ResponseEntity<ProdModel>(HttpStatus.NOT_FOUND);
			  }
			  return new ResponseEntity<ProdModel>(product, HttpStatus.OK);	
	}
	
	
	
	
	
	@RequestMapping(value = "/Product/upadate/{id}",method = RequestMethod.PUT)
	public ResponseEntity<ProdModel> updateProduct(@PathVariable("id") int productid,@RequestBody ProdModel product)
	{
		HttpHeaders headers = new HttpHeaders();
		ProdModel product1 = productService.getProductById(productid);
		
		if (product1 == null) {
			   return new ResponseEntity<ProdModel>(HttpStatus.NOT_FOUND);
			  }
		else if (product == null) {
			   return new ResponseEntity<ProdModel>(HttpStatus.BAD_REQUEST);
			  }
		
		productService.updateProdModel(product);
			  headers.add("Product Updated  - ", String.valueOf(productid));
			  return new ResponseEntity<ProdModel>(product, headers, HttpStatus.OK);
}
	
	public ResponseEntity<ProdModel> addProduct(@RequestBody ProdModel product) {
		  HttpHeaders headers = new HttpHeaders();
		  if (product == null) {
		   return new ResponseEntity<ProdModel>(HttpStatus.BAD_REQUEST);
		  }
		  productService.addProdModel(product);
		  headers.add("Employee Created  - ", String.valueOf(product.getProductId()));
		  return new ResponseEntity<ProdModel>(product, headers, HttpStatus.CREATED);
		 }

	
	
	
	
	
	
	@RequestMapping(value = "/product/delete/{id}", method = RequestMethod.DELETE,produces = "application/json")
	public ResponseEntity<ProdModel> deleteProduct(@PathVariable("id") int productid)
	{
		HttpHeaders headers = new HttpHeaders();
		ProdModel product1 = productService.getProductById(productid);
		
		if (product1 == null) {
			   return new ResponseEntity<ProdModel>(HttpStatus.NOT_FOUND);
		}	
		    productService.deleteProdModel(productid);
			  headers.add("Product Updated  - ", String.valueOf(productid));
			  return new ResponseEntity<ProdModel>(product1, headers, HttpStatus.OK);
	
	
	
	
}
}